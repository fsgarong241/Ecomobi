# foss-ecomobi
Free and Open Source Auto Generated Content EcoMobi PHP Script
### Cara Install foss-ecomobi
#### 1. Download Repository Ini
#### 2. Upload Ke Hosting
#### 3. Ganti Token EcoMobi Yang Ada Pada Line 1 di index.php
#### 4. Tes Bro :b
